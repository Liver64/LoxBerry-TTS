# LoxBerry-TTS
Text-to-speech Plugin for LoxBerry
Installation and usage ist explained in LoxWiki: https://www.loxwiki.eu/x/uoFYAg
